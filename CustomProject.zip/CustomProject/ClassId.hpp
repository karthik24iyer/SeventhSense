#pragma once

//knife
#define knifeCT 42
#define knifeT 59
#define c4 49

//scopes
#define awpDef 9
#define scoutDef 40
#define awp 262153
#define scout 262184

//gays
#define g3sg 11
#define scar 38

//rifles
#define ak47Def 7
#define augDef 8
#define ak47 262151
#define gali 13
#define sg 39
#define m4a4 16
#define aug 262152
#define famas 10
#define m4a1s 262204
#define m4a1sAlt 60

//heavy
#define xm1014 25
#define negev 28
#define mag7 27

//smgs
#define mp9Def 34
#define mac10Def 17
#define p90Def 19
#define umpDef 24
#define mp9 786466
#define p90 786451
#define ump 786456
#define bison 26
#define mac10 786449
#define mp7 33
#define mp5 262167

//pistols
#define p250Def 36
#define glock 4
#define p250 786468
#define dgle 1
#define tec9 30
#define dualB 2
#define five7 3
#define usps 262205
#define cz 262207
#define p2000 32