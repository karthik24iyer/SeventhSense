#include<iostream>

public class MemoryRW {

};